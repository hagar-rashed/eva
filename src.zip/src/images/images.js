const Images={
    original_476:require("./images/original-4764cf.png"),
    path_66:require("./images/Path 66.png"),
    svgexport_7:require("./images/svgexport-7.png"),
    svgexport_7_1:require("./images/svgexport-7 (15.png"),
    svgexport_7_2:require("./images/svgexport-7 (16.png"),
    Path_199:require("./images/Path 199.png"),
    Group_132:require("./images/Group 132.png"),
    g3664:require("./images/g3664.png"),
    Layer_8:require("./images/Layer 8.png"),
    Path_22:require("./images/Path 22.png"),
    svgexport_7_4:require("./images/svgexport-7 (4).png"),
    svgexport_7_5:require("./images/svgexport-7 (5).png"),
    svgexport_7_6:require("./images/svgexport-7 (6).png"),
    svgexport_7_9:require("./images/svgexport-7 (9).png"),
    Mask_Group_19:require("./images/Mask Group 19.png"),
    path_102:require("./images/Path 102.png"),
}
export default Images;


