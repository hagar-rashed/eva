import './sidenav.css';
import Images from '../../../images/images';
function Sidenav (){
    return(
        <>
           <div className="sidenav">
              <div className='images'>
      
                <img src={Images.original_476} />
              </div>
              <div className='images'>
                <img src={Images.path_66} />
              </div>
              <div className='images'>
                <img src={Images.svgexport_7} />
              </div>
              <div className='images'>
                <img src={Images.svgexport_7_1} />
              </div>
              <div className='images'>
                <img src={Images.svgexport_7_2} />
              </div>
              <div className='images'>
                <img src={Images.Path_199} />
              </div>
           </div>
        </>
    );
}

export default Sidenav;
