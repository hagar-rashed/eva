// import '.././popular_places/popular_places.css';
import Images from "../../../images/images";

function Recommended() {
  return (
    <div className="container-fluid">
      <div className="row justify-content-center">
        <div className="popular_title col-12">
          <h2>recomendedd in your place</h2>
        </div>
        <div className="popular_cards row pt-3">
      
        </div>
      </div>
    </div>
  );
}
export default Recommended;
