import './setting.css';

function Setting(){
   return(
     <div className='setting'>
        <div className='container-fluid'>
            <div className='row'>

                <div className='col-lg-4'>
                  <div className='account-home'>
                  <div className='account-title'>
                        <h3>Account</h3>
                    </div>
                  <div className='title pt-4'>
                        <p>Account</p>
                    </div>
                    <div className='account-setting '>
                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>

                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>
                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>
                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>
                    </div>
                  </div>
                  <div className='account-home'>
                    <div className='title'>
                        <p>Account</p>
                    </div>
                    <div className='account-setting'>
                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>

                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>
                        <div className='setting-edit'>
                            <p className='text'>
                               details
                            </p>
                            <p className='icon'>
                                 I
                            </p>
                        </div>
                     
                    </div>
                  </div>
                </div>
                <div className='col-lg-7'>
                    <div className='account-setting-details'>
                        <div className='setting-detials'>
                            <p><strong>Notification Settings</strong></p>
                            <p>llllllllllllllllllllllllllll</p>
                        </div>
                        <div className='row'>
                            <div className='col-5'>

                            </div>
                            <div className='col-7'>
                                
                            </div>
                        </div>
                        </div> 
            

                </div>
            </div>
        </div>
     </div>
   )
}

export default Setting;